void login(char name[], char password[]);
void signup(char name[], char address[], char mobileno[], char username[], char password[]);